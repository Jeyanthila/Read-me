<?php

$config=[
"token" => "xxxxxxxxxxxxxxxxx",
"deviceid" => "xxxxxxxxxxxxxxxxx",
"userid" => "xxxxxxxxxxxxxxxxx",
"acckey" => "MoeCube-xxxxxxxxxxxxxxxxx",
"nonce" => "xxxxxxxxxxxxxxxxx",
];

$komen=[
"good",
"up up up",
"nice",
"headshoot",
"subcribe chanel adi bordir",
];

$post=[
"subcribe chanel adi bordir",
];



?>